clc;
clear all;
close all;
%%
Input_Image=imread('5.jpg');
imshow(Input_Image);title("Uneven illuminated input image");
%%%Convert the input image from RGB colour space to HSV colour space%%%
HSV_Image = rgb2hsv(Input_Image);
%%%Seperate Hue, Saturation and Value Components%%%
Hue_Component=HSV_Image(:,:,1);
Saturation_Component=HSV_Image(:,:,2);
Value_Component=HSV_Image(:,:,3);
Value_Component_Double=double(Value_Component);
figure; imshow(Value_Component_Double); title("V channel image");
Value_Component = Value_Component_Double*255;
%%
%Load the trained modified ResNet model
load("Modified_ResNet_Pretrained_Model.mat")
Value_Component= imresize(Value_Component,[224 224]);
%Predict the SCP of the image
SC_Predicted = abs(predict(ccnet,Value_Component))
%%
Enhanced_Image=Counter_Exponential_Transform(Input_Image,SC_Predicted);
figure,imshow(Enhanced_Image,'Border','tight'); title("IECET equalized output image");

%% 
