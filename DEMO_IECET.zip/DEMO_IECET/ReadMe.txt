
Please download the trained modified ResNet model 

https://drive.google.com/file/d/1maT6kdvdJc-_cu41Ceuy1QyGogxzKUdu/view?usp=sharing